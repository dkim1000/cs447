class q1 {
	public static void main(String[] args) {
		double modulo = -5%2;
		System.out.println(modulo);
	}
}