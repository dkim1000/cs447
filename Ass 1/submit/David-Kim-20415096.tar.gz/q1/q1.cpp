#include <iostream>

using namespace std;

int main()
{
	double modulo = -5%2;
	cout<<modulo<<endl;
	return 0;
}